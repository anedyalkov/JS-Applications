const eventService = (() => {

    function getAllEvents() {
         return kinvey.get('appdata', 'events', 'kinvey');
     }
    function createEvent(data) {
        return kinvey.post('appdata', 'events', 'kinvey', data)
    }

    function getAEvent(id) {
        return kinvey.get('appdata', `events/${id}`, 'kinvey');
    }

    function deleteEvent(id) {
        return kinvey.remove('appdata', `events/${id}`, 'kinvey');
    }



    return {
        createEvent,
        getAllEvents,
        getAEvent,
        deleteEvent
    }
})()